# Mastermind

First coursework for CS141
